﻿using Microsoft.EntityFrameworkCore;
using SntLB.Models.ModelsDb;
using SntLB.Models.ModelsDomain;
using SntLB.Repositoryes.Intetface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SntLB.Repositoryes.Realization
{
    public class UserRepository:BaseRepository<User>, IUserRepository
    {
        private readonly SntContext _context;
        public UserRepository(SntContext context):base(context) 
        {
            _context = context;
        }

        public async Task<User?> Login(UserAuth entity)
        {
            User user = await _context.Users.FirstOrDefaultAsync(x => x.Login.Trim() == entity.UserLogin);
            if (user != null)
            {
                if (user.Password.Trim() == entity.UserPassword )
                {
                    return user;
                }

            }
            return null;
        }

        public async Task UpdateUser(User entity)
        {
            _context.Users.Update(entity);
            await Save();
        }
    }
}
