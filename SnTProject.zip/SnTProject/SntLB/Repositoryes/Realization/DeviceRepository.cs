﻿using SntLB.Models.ModelsDb;
using SntLB.Repositoryes.Intetface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SntLB.Repositoryes.Realization
{
    public class DeviceRepository:BaseRepository<Device>, IDeviceRepository
    {
        private readonly SntContext _context;
        public DeviceRepository(SntContext context):base(context) 
        {
            _context = context;
        }

        public async Task UpdateDevice(Device entity)
        {
            _context.Devices.Update(entity);
            await Save();
        }
    }
}
