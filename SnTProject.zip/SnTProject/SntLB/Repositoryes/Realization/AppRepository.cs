﻿using SntLB.Models.ModelsDb;
using SntLB.Repositoryes.Intetface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SntLB.Repositoryes.Realization
{
    public class AppRepository:BaseRepository<App>, IAppsRepository
    {
        private readonly SntContext _context;
        public AppRepository(SntContext context):base(context) 
        {
            _context = context;
        }

        public async Task UpdateApp(App entity)
        {
           _context.Apps.Update(entity);
            await Save();
        }
    }
}
