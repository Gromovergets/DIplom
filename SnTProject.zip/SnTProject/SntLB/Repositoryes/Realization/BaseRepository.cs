﻿using Microsoft.EntityFrameworkCore;
using SntLB.Models.ModelsDb;
using SntLB.Repositoryes.Intetface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace SntLB.Repositoryes.Realization
{
    public class BaseRepository<T> : IBaseRepository<T> where T : class
    {
        private readonly SntContext _context;
        internal DbSet<T> _set;
        public BaseRepository(SntContext context)
        {
            _context = context;
            _set = _context.Set<T>();

        }
        public async Task CreateEntity(T entity)
        {
            await _set.AddAsync(entity);
            await Save();

        }

        public async Task<T> Get(Expression<Func<T, bool>> filter = null)
        {
            IQueryable<T> query = _set;


            if (filter != null)
            {
                query = query.Where(filter);
            }

            return await query.FirstOrDefaultAsync();
        }

        public async Task<ICollection<T>> GetAll()
        {
            return await _set.ToListAsync();
        }

        public async Task RemoveEntity(T entity)
        {
            _set.Remove(entity);
            await Save();
        }


        public async Task Save()
        {
            await _context.SaveChangesAsync();
        }
    }
}
