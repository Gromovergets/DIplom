﻿using SntLB.Models.ModelsDb;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SntLB.Repositoryes.Intetface
{
    public interface IDeviceRepository:IBaseRepository<Device>
    {
        Task UpdateDevice(Device entity);

    }
}
