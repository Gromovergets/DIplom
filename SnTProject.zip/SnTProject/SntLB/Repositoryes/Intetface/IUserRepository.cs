﻿using SntLB.Models.ModelsDb;
using SntLB.Models.ModelsDomain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SntLB.Repositoryes.Intetface
{
    public interface IUserRepository:IBaseRepository<User>
    {
        Task UpdateUser(User entity);

        Task<User> Login(UserAuth entity);

    }
}
