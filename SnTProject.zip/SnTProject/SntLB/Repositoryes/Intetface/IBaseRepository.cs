﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace SntLB.Repositoryes.Intetface
{
    public interface IBaseRepository<T> where T : class
    {
        Task<ICollection<T>> GetAll();
        Task<T> Get(Expression<Func<T, bool>>? filter = null);
        Task CreateEntity(T entity);
        Task RemoveEntity(T entity);
        Task Save();
    }
}
