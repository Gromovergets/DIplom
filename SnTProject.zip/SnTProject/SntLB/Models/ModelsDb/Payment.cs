﻿using System;
using System.Collections.Generic;

namespace SntLB.Models.ModelsDb;

public partial class Payment
{
    public int Id { get; set; }

    public string? Accrual { get; set; }

    public DateTime? Date { get; set; }

    public string? Deposit { get; set; }

    public int? IdPaymentAccount { get; set; }

    public string? Remains { get; set; }

    public string? Status { get; set; }

    public virtual PaymentAccount? IdPaymentAccountNavigation { get; set; }
}
