﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace SntLB.Models.ModelsDb;

public partial class SntContext : DbContext
{
    public SntContext()
    {
    }

    public SntContext(DbContextOptions<SntContext> options)
        : base(options)
    {
    }

    public virtual DbSet<App> Apps { get; set; }

    public virtual DbSet<Device> Devices { get; set; }

    public virtual DbSet<Indication> Indications { get; set; }

    public virtual DbSet<Payment> Payments { get; set; }

    public virtual DbSet<PaymentAccount> PaymentAccounts { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=LAPTOP-KLBSCP3I\\SQLEXPRESS;Initial Catalog=SNT;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<App>(entity =>
        {
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Area)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("area");
            entity.Property(e => e.IdOwner).HasColumnName("id_owner");
            entity.Property(e => e.LivingArea)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("living_area");
            entity.Property(e => e.LivingPeople)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("living_people");
            entity.Property(e => e.RegesterPeople)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("regester_people");
            entity.Property(e => e.TypeFlat)
                .HasMaxLength(50)
                .HasColumnName("type_flat");
            entity.Property(e => e.TypeOwner)
                .HasMaxLength(50)
                .HasColumnName("type_owner");

            entity.HasOne(d => d.IdOwnerNavigation).WithMany(p => p.Apps)
                .HasForeignKey(d => d.IdOwner)
                .HasConstraintName("FK_Apps_User");
        });

        modelBuilder.Entity<Device>(entity =>
        {
            entity.ToTable("Device");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.DateCheck)
                .HasColumnType("datetime")
                .HasColumnName("date_check");
            entity.Property(e => e.IdApp).HasColumnName("id_app");
            entity.Property(e => e.Number)
                .HasMaxLength(20)
                .IsFixedLength()
                .HasColumnName("number");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .HasColumnName("type");

            entity.HasOne(d => d.IdAppNavigation).WithMany(p => p.Devices)
                .HasForeignKey(d => d.IdApp)
                .HasConstraintName("FK_Device_Apps");
        });

        modelBuilder.Entity<Indication>(entity =>
        {
            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Data)
                .HasMaxLength(20)
                .IsFixedLength()
                .HasColumnName("data");
            entity.Property(e => e.Date)
                .HasColumnType("datetime")
                .HasColumnName("date");
            entity.Property(e => e.IdDevice).HasColumnName("id_device");

            entity.HasOne(d => d.IdDeviceNavigation).WithMany(p => p.Indications)
                .HasForeignKey(d => d.IdDevice)
                .HasConstraintName("FK_Indications_Device");
        });

        modelBuilder.Entity<Payment>(entity =>
        {
            entity.ToTable("payment");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Accrual)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("accrual");
            entity.Property(e => e.Date)
                .HasColumnType("datetime")
                .HasColumnName("date");
            entity.Property(e => e.Deposit)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("deposit");
            entity.Property(e => e.IdPaymentAccount).HasColumnName("id_payment_account");
            entity.Property(e => e.Remains)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("remains");
            entity.Property(e => e.Status)
                .HasMaxLength(20)
                .HasColumnName("status");

            entity.HasOne(d => d.IdPaymentAccountNavigation).WithMany(p => p.Payments)
                .HasForeignKey(d => d.IdPaymentAccount)
                .HasConstraintName("FK_payment_Payment_Account");
        });

        modelBuilder.Entity<PaymentAccount>(entity =>
        {
            entity.ToTable("Payment_Account");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Balance)
                .HasMaxLength(100)
                .IsFixedLength()
                .HasColumnName("balance");
            entity.Property(e => e.Date)
                .HasColumnType("datetime")
                .HasColumnName("date");
            entity.Property(e => e.IdApp).HasColumnName("id_app");

            entity.HasOne(d => d.IdAppNavigation).WithMany(p => p.PaymentAccounts)
                .HasForeignKey(d => d.IdApp)
                .HasConstraintName("FK_Payment_Account_Apps");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("User");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.FullName)
                .HasMaxLength(100)
                .HasColumnName("full_name");
            entity.Property(e => e.Login)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("login");
            entity.Property(e => e.Password)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("password");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
