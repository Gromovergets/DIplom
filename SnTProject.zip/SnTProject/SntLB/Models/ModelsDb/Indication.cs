﻿using System;
using System.Collections.Generic;

namespace SntLB.Models.ModelsDb;

public partial class Indication
{
    public int Id { get; set; }

    public string? Data { get; set; }

    public DateTime? Date { get; set; }

    public int? IdDevice { get; set; }

    public virtual Device? IdDeviceNavigation { get; set; }
}
