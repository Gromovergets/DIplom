﻿using System;
using System.Collections.Generic;

namespace SntLB.Models.ModelsDb;

public partial class App
{
    public int Id { get; set; }

    public int? IdOwner { get; set; }

    public string? Area { get; set; }

    public string? TypeOwner { get; set; }

    public string? TypeFlat { get; set; }

    public string? LivingArea { get; set; }

    public string? RegesterPeople { get; set; }

    public string? LivingPeople { get; set; }

    public virtual ICollection<Device> Devices { get; set; } = new List<Device>();

    public virtual User? IdOwnerNavigation { get; set; }

    public virtual ICollection<PaymentAccount> PaymentAccounts { get; set; } = new List<PaymentAccount>();
}
