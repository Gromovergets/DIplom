﻿using System;
using System.Collections.Generic;

namespace SntLB.Models.ModelsDb;

public partial class PaymentAccount
{
    public int Id { get; set; }

    public string? Balance { get; set; }

    public DateTime? Date { get; set; }

    public int? IdApp { get; set; }

    public virtual App? IdAppNavigation { get; set; }

    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();
}
