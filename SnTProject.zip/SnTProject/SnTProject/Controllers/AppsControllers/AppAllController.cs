﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SntLB.Repositoryes.Intetface;

namespace SnTProject.Controllers.AppsControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppAllController : ControllerBase
    {
        private readonly IAppsRepository _repos;
        public AppAllController(IAppsRepository irep)
        {
            _repos = irep;
        }

        [HttpGet(Name = "GetAllApp")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetAllApps()
        {
            return Ok(await _repos.GetAll());
        }
    }
}
