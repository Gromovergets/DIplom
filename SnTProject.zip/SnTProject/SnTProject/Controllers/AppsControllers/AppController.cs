﻿using Azure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SntLB.Models;
using SntLB.Models.ModelsDb;
using SntLB.Repositoryes;
using SntLB.Repositoryes.Intetface;

namespace SnTProject.Controllers.AppsControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppController : ControllerBase
    {
        private readonly IAppsRepository _repos;
        public AppController(IAppsRepository irep)
        {
            _repos = irep;
        }

        [HttpGet(Name = "GetAppByID")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetAppById(int id)
        {
            return Ok(await _repos.Get(x => x.Id == id));
        }

        [HttpDelete(Name = "DeleteApp")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> DeleteApp(int id)
        {
            try
            {
                var app = await _repos.Get(x => x.Id == id);
                await _repos.RemoveEntity(app);
                return NoContent();
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }
        [HttpPost(Name = "CreateApp")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateApp([FromBody] App app)
        {
            await _repos.CreateEntity(app);
            return Ok();
        }

        [HttpPut(Name = "UpdateApp")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UptadeApp( App app)
        {
            await _repos.UpdateApp(app);
            return Ok();
        }
    }
}
