using Microsoft.EntityFrameworkCore;
using SntLB.Models.ModelsDb;
using SntLB.Repositoryes.Intetface;
using SntLB.Repositoryes.Realization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddRazorPages();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
//builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddControllersWithViews()
    .AddNewtonsoftJson(options =>
    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
);


builder.Services.AddDbContext<SntContext>(options =>
{
    options.UseSqlServer("Data Source=LAPTOP-KLBSCP3I\\SQLEXPRESS;Initial Catalog=SNT;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False");
});
//builder.Services.AddScoped <Irepository,Repository>();
builder.Services.AddScoped<IAppsRepository, AppRepository>();
builder.Services.AddScoped<IDeviceRepository, DeviceRepository>(); 
builder.Services.AddScoped<IUserRepository, UserRepository>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "v1");
    options.RoutePrefix = string.Empty;
});

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthorization();

app.UseAuthorization();


app.MapControllerRoute(name: "default", pattern: "{controller}/{action}");

app.Run();
